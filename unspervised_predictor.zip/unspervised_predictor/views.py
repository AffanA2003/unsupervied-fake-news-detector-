from django.shortcuts import render
from unspervised_predictor import model
from django.shortcuts import redirect


def homepage(request):
    return render(request, "index.html")

def redirectd(request):
    if request.method == "POST" and "get" in request.POST:
        return redirect('terms')

    return render(request, 'index.html')
def trys(request):
    data = {'result': "____"}
    if request.method == "POST" and "predict" in request.POST:
        detector = model.FakeNewsDetector('unspervised_predictor/gmm_model.pkl', 'unspervised_predictor/svd_model.pkl', 'unspervised_predictor/tfidf_vectorizer.pkl')

        # Get user input
        user_input = request.POST.get('text')

        # Preprocess and predict
        user_svd = detector.preprocess_input(user_input)
        prediction = detector.predict_label(user_svd)

        # Print the prediction
        print("Prediction:", prediction)

        data = {'result': prediction}  # Update the value of data with the prediction

        return render(request, "terms.html", data)


    return render(request, "terms.html", data)
def terms(request):
    return render(request, "terms.html")

def report(request):
    return render(request,"report.html")

def redirect_report(request):
    if request.method == "POST" and "report" in request.POST:
        return redirect('report')
    return render(request, 'index.html')

def back(request):
    if request.method == "POST" and "index" in request.POST:
        return redirect('homepage')
    return render(request, 'report.html')